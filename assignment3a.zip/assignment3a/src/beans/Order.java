package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Order {
	public String Order_Number = null;
	public String Product_Name  = null;
	public float Price = 0;
	public int Quantity = 0;
	
	public Order(String order_number, String product_name, float price, int quantity) {
		Order_Number = order_number;
		Product_Name = product_name;
		Price = price;
		Quantity = quantity;
	}

	public String getOrder_Number() {
		return Order_Number;
	}

	public void setOrder_Number(String order_Number) {
		Order_Number = order_Number;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public float getPrice() {
		return Price;
	}

	public void setPrice(float price) {
		Price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
		
	
	

}
