package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped

public class User 
{
	
	@NotNull(message = "Please Enter a First Name")
	@Size(min=5, max=15,  message = "You must enter a first name with atleast 2 chars and at most 20")
String firstName = "";
	
	@NotNull(message = "Please Enter a Last Name")
	@Size(min=5, max=15,  message = "You must enter a last name with atleast 2 chars and at most 20")
String lastName = "";


	@NotNull(message = "Please Enter an email")
	@Size(min=5, max=15,  message = "You must enter an email address")
String email = "";

	@NotNull(message = "Please Enter a password")
	@Size(min=5, max=15,  message = "You must enter a password with atleast 2 chars and at most 20")
String password = "";

	@NotNull(message = "Please Enter your phone number")
	@Size(min=5, max=15,  message = "You must enter a last name with atleast 2 chars and at most 20")
String phoneNumber = "";

	@NotNull(message = "Please enter your address")
	@Size(min=5, max=15,  message = "You must enter a last name with atleast 2 chars and at most 20")
String address = "";

	
	
public User()
{
	this.firstName = "";
	this.lastName = "";
	this.email = "";
	this.password = "";
	this.phoneNumber = "";
	this.address = "";
	
	
}

public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

	
}
