package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import java.util.List;
import java.util.ArrayList;


@ManagedBean
@ViewScoped
public class Orders {

	List<Order>orders = new ArrayList<Order>();
	
	public Orders()
	{
		orders.add(new Order("0001","offWhite Tee", (float)200.3, 30));
		orders.add(new Order("0002","Nike Socks", (float)35.3, 30));
		orders.add(new Order("0003","Obey Hoodie", (float)60.7, 30));
		orders.add(new Order("0004","Balenciaga Speed trainers", (float)280.3, 30));
		orders.add(new Order("0005","YSL Denim", (float)843.3, 30));
		orders.add(new Order("0006","Gucci phone case", (float)100.3, 30));
		
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	

}
